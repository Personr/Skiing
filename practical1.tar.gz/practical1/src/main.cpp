#include "../include/Viewer.hpp"
#include "../include/log.hpp"

#include <iostream>


static void initialize_scene (Viewer& viewer)
{
    // create your renderables and shader programs
    // and add them to the viewer
}

int main()
{
    // initialize_scene(viewer);

    std::cout << "Hello World!" << std::endl;

    return EXIT_SUCCESS;
}
